package com.studentloanservices.sls;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SlsApplication.class, args);
	}

}
