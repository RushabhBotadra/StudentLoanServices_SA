package com.studentloanservices.sls;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlsApplicationTests {

	@Test
	void contextLoads() {
	}

}
